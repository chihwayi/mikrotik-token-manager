-- Add VPN support to the system

-- VPN packages table
CREATE TABLE vpn_packages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    vpn_type VARCHAR(20) NOT NULL CHECK (vpn_type IN ('pptp', 'l2tp', 'openvpn')),
    duration_hours INTEGER NOT NULL,
    data_limit_mb INTEGER NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    max_concurrent_sessions INTEGER DEFAULT 1,
    description TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- VPN users table
CREATE TABLE vpn_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    package_id UUID NOT NULL REFERENCES vpn_packages(id),
    router_id UUID NOT NULL REFERENCES routers(id),
    staff_id UUID NOT NULL REFERENCES users(id),
    vpn_type VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'disabled', 'expired')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    last_login TIMESTAMP,
    bytes_uploaded BIGINT DEFAULT 0,
    bytes_downloaded BIGINT DEFAULT 0
);

-- VPN sessions table
CREATE TABLE vpn_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vpn_user_id UUID NOT NULL REFERENCES vpn_users(id),
    router_id UUID NOT NULL REFERENCES routers(id),
    client_ip VARCHAR(50),
    client_mac VARCHAR(50),
    session_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_end TIMESTAMP,
    bytes_uploaded BIGINT DEFAULT 0,
    bytes_downloaded BIGINT DEFAULT 0,
    active BOOLEAN DEFAULT true
);

-- Add VPN configuration to routers
ALTER TABLE routers 
ADD COLUMN IF NOT EXISTS vpn_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS pptp_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS l2tp_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS openvpn_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS vpn_ip_pool VARCHAR(50) DEFAULT '192.168.100.2-192.168.100.100';

-- Indexes for performance
CREATE INDEX idx_vpn_users_router ON vpn_users(router_id);
CREATE INDEX idx_vpn_users_staff ON vpn_users(staff_id);
CREATE INDEX idx_vpn_users_status ON vpn_users(status);
CREATE INDEX idx_vpn_sessions_user ON vpn_sessions(vpn_user_id);
CREATE INDEX idx_vpn_sessions_active ON vpn_sessions(active);

-- Insert default VPN packages
INSERT INTO vpn_packages (name, vpn_type, duration_hours, data_limit_mb, price, description) VALUES
('PPTP 1 Hour', 'pptp', 1, 500, 1.50, '1 hour VPN access via PPTP with 500MB data'),
('PPTP Daily', 'pptp', 24, 2048, 5.00, 'Daily VPN access via PPTP with 2GB data'),
('L2TP 1 Hour', 'l2tp', 1, 500, 2.00, '1 hour secure VPN access via L2TP with 500MB data'),
('L2TP Daily', 'l2tp', 24, 2048, 6.00, 'Daily secure VPN access via L2TP with 2GB data'),
('OpenVPN 1 Hour', 'openvpn', 1, 1024, 2.50, '1 hour premium VPN access via OpenVPN with 1GB data'),
('OpenVPN Daily', 'openvpn', 24, 5120, 8.00, 'Daily premium VPN access via OpenVPN with 5GB data');