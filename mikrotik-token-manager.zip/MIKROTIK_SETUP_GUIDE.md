# MikroTik Router Setup Guide for Token Management System

This guide walks you through setting up a fresh MikroTik router to work with the Token Management System.

## 📋 Prerequisites

- Fresh MikroTik router (RouterOS 6.49.19 or later)
- Winbox or WebFig access
- Internet connection via WAN port (ether1)
- Computer for configuration

## 🔧 Step 1: Initial Router Access

### Connect to Router
1. **Connect ethernet cable** from your computer to ether2-5
2. **Open Winbox** or go to `http://192.168.88.1` in browser
3. **Login** with username `admin` (no password initially)

### Set Admin Password
```bash
/user set admin password=Password123!
```

## 🌐 Step 2: Configure Internet Connection

### Set WAN Interface (if using DHCP)
```bash
/ip dhcp-client add interface=ether1 disabled=no
```

### Verify Internet Connection
```bash
/ping 8.8.8.8 count=3
```

## 📡 Step 3: Configure Hotspot System

### Run Hotspot Setup Wizard
```bash
/ip hotspot setup
```

**Wizard Configuration:**
- **Hotspot interface**: `bridge` (or `ether2` if no bridge)
- **Local address**: `192.168.88.1/24`
- **Address pool**: `192.168.88.10-192.168.88.254`
- **DNS servers**: `8.8.8.8`
- **DNS name**: `cafe.local` (or leave empty)
- **SMTP server**: (press Enter to skip)
- **SSL certificate**: (press Enter to skip)
- **Local hotspot user**: (press Enter to skip)

### Fix DNS Issues (if needed)
```bash
# Remove DNS name to prevent redirect issues
/ip hotspot profile set hsprof1 dns-name=""

# Set DNS servers
/ip dns set servers=8.8.8.8,8.8.4.4 allow-remote-requests=yes
```

## 🔐 Step 4: Enable RouterOS API

### Enable API Service
```bash
/ip service enable api
/ip service set api port=8728 address=0.0.0.0/0
```

### Create API User
```bash
/user add name=api-user password=Password123! group=full
```

### Verify API Service
```bash
/ip service print where name=api
```

## 🛡️ Step 5: Configure Firewall Rules

### Allow API Access from Local Network
```bash
# Allow API access from hotspot network
/ip firewall filter add chain=input src-address=192.168.88.0/24 protocol=tcp dst-port=8728 action=accept place-before=0

# Allow API access in hotspot chains
/ip firewall filter add chain=hs-input src-address=192.168.88.0/24 dst-port=8728 protocol=tcp action=accept place-before=0
/ip firewall filter add chain=pre-hs-input src-address=192.168.88.0/24 dst-port=8728 protocol=tcp action=accept place-before=0
```

### Allow API Access from Remote Server (for production)
```bash
# Replace SERVER_IP with your actual server IP
/ip firewall filter add chain=input src-address=SERVER_IP protocol=tcp dst-port=8728 action=accept place-before=0
```

## 📶 Step 6: Optimize WiFi Configuration (Optional)

### Disable Dual-Band if Needed
```bash
# Check wireless interfaces
/interface wireless print

# Disable 5GHz if you want single band
/interface wireless disable wlan2

# Or disable 2.4GHz to keep only 5GHz
/interface wireless disable wlan1
```

### Set Custom WiFi Name
```bash
# Change WiFi name (replace with your desired name)
/interface wireless set wlan1 ssid="YourCafeName-WiFi"
```

## 🧪 Step 7: Test Configuration

### Test API Access Locally
```bash
# From a computer on the WiFi network
curl -v --connect-timeout 5 192.168.88.1:8728
```
**Expected result**: Connection successful (will hang waiting for data - this is normal)

### Test Hotspot Login
1. **Connect** to the WiFi network
2. **Open browser** and go to any website
3. **Should redirect** to hotspot login page
4. **Login page** should appear at `http://192.168.88.1/login`

## 🔄 Step 8: Create Default Profile

### Add Default Hotspot Profile
```bash
/ip hotspot user profile add name=default shared-users=1
```

### Verify Profile Exists
```bash
/ip hotspot user profile print
```

## 📊 Step 9: Verify Complete Setup

### Check All Services
```bash
# Verify hotspot is running
/ip hotspot print

# Verify API is enabled
/ip service print where name=api

# Verify firewall rules
/ip firewall filter print where dst-port=8728

# Check user profiles
/ip hotspot user profile print
```

### Test Token Creation (Manual)
```bash
# Create a test token manually
/ip hotspot user add name=TEST123 password=TEST123 limit-uptime=1h limit-bytes-total=524288000 profile=default

# Verify token was created
/ip hotspot user print where name=TEST123

# Remove test token
/ip hotspot user remove [find name=TEST123]
```

## 🌍 Step 10: Production Setup (Remote Access)

### For Internet Access (if needed)
```bash
# Add port forwarding for API (if behind NAT)
/ip firewall nat add chain=dstnat dst-port=8728 protocol=tcp action=dst-nat to-addresses=192.168.88.1 to-ports=8728

# Allow API from specific server IP
/ip firewall filter add chain=input src-address=YOUR_SERVER_IP protocol=tcp dst-port=8728 action=accept place-before=0
```

## ✅ Configuration Complete!

Your MikroTik router is now ready for the Token Management System with:

- ✅ **Hotspot configured** on bridge interface
- ✅ **RouterOS API enabled** on port 8728
- ✅ **API user created** with full permissions
- ✅ **Firewall rules** allowing API access
- ✅ **Default profile** for token users
- ✅ **WiFi network** broadcasting

## 🔗 Next Steps

1. **Add router to Token Management System**:
   - **IP Address**: `192.168.88.1` (local) or public IP (remote)
   - **API Port**: `8728`
   - **Username**: `api-user`
   - **Password**: `Password123!`

2. **Test token generation** from the system
3. **Verify tokens appear** in `/ip hotspot user print`
4. **Test customer login** with generated voucher codes

## 🚨 Security Notes

- **Change default passwords** in production
- **Use strong API passwords**
- **Restrict API access** to specific IPs only
- **Enable HTTPS** for web management
- **Regular firmware updates**

## 🛠️ Troubleshooting

### API Connection Issues
```bash
# Check if API is listening
/ip service print where name=api

# Check firewall rules
/ip firewall filter print where chain=input

# Test local connectivity
/tool ping address=192.168.88.1 count=3
```

### Hotspot Issues
```bash
# Check hotspot status
/ip hotspot print

# Check active users
/ip hotspot active print

# Check user profiles
/ip hotspot user profile print
```

### WiFi Issues
```bash
# Check wireless interfaces
/interface wireless print

# Check bridge configuration
/interface bridge print
/interface bridge port print
```

---

**Your MikroTik router is now fully configured and ready for centralized token management!** 🎉